// Shuttle Split: phone alerts for the main group (Badminton Family).
// Sends a push notification to the phones that switched on "Phone alerts" in the app.
const { onDocumentCreated, onDocumentUpdated, onDocumentWritten } = require('firebase-functions/v2/firestore');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { setGlobalOptions } = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();
setGlobalOptions({ region: 'asia-south1', maxInstances: 3 });
const db = admin.firestore();
const APP = 'https://pavan8009.github.io/shuttle-split/';
const P = 'shuttleSplit_';
const key = n => String(n || '').trim().toLowerCase().replace(/\s+/g, ' ');
const first = n => String(n || '').trim().split(/\s+/)[0];
const inr = n => '₹' + Math.round(+n || 0).toLocaleString('en-IN');

async function tokens(filter) {
  const q = await db.collection(P + 'tokens').get();
  return q.docs.map(d => ({ id: d.id, ...d.data() })).filter(t => t.token && (!filter || filter(t)));
}

// Admin settings (Manage › Player permissions › Alert types): who gets each type, quiet hours
const DEF = { announce: 'must', poll: 'all', game: 'all', ask: 'all', post: 'all', occasion: 'all', proposal: 'on', comment: 'on', avo: 'on', chal: 'on', paid: 'on', pay: 'on', idea: 'on', ticket: 'on', guest: 'on', pass: 'all' };
let CFG = { at: 0, a: {} };
async function settings() {
  if (Date.now() - CFG.at < 60000) return CFG.a;
  const d = await db.collection(P + 'config').doc('main').get();
  CFG = { at: Date.now(), a: (d.exists && d.data().alerts) || {} };
  return CFG.a;
}
function quietNow(q) {
  if (!q || !q.on) return false;
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })), m = now.getHours() * 60 + now.getMinutes();
  const mins = v => { const [h, mm] = String(v || '0:0').split(':').map(Number); return h * 60 + (mm || 0); };
  const a = mins(q.from || '22:00'), b = mins(q.to || '07:00');
  return a <= b ? m >= a && m < b : m >= a || m < b;
}
async function send(list, title, body, link = '', tag = '', type = 'post') {
  const cfg = await settings(), mode = (cfg.t && cfg.t[type]) || DEF[type] || 'all';
  if (mode === 'off') return;
  if (mode === 'adm') list = list.filter(t => t.org);
  if (mode !== 'must') {
    if (quietNow(cfg.quiet)) return;
    list = list.filter(t => !(t.mute || []).includes(type));
  }
  if (!list.length) return;
  const toks = [...new Set(list.map(t => t.token))];
  for (let i = 0; i < toks.length; i += 500) {
    const chunk = toks.slice(i, i + 500);
    const res = await admin.messaging().sendEachForMulticast({
      tokens: chunk,
      data: { title, body, link: APP + link, tag },
      webpush: { notification: { title, body, icon: APP + 'icon-192.png', tag: tag || undefined }, fcmOptions: { link: APP + link } }
    });
    // forget phones that uninstalled or turned alerts off
    const bad = [];
    res.responses.forEach((r, j) => {
      const c = r.error && r.error.code;
      if (c === 'messaging/registration-token-not-registered' || c === 'messaging/invalid-registration-token') bad.push(chunk[j]);
    });
    for (const t of bad) {
      const q = await db.collection(P + 'tokens').where('token', '==', t).get();
      await Promise.all(q.docs.map(d => d.ref.delete()));
    }
  }
}
const everyoneBut = n => tokens(t => key(t.name) !== key(n));
const only = n => tokens(t => key(t.name) === key(n));
const organizers = () => tokens(t => t.org);

// Club posts: help requests, announcements, photos, tips…
exports.onPost = onDocumentCreated(P + 'posts/{id}', async e => {
  const x = e.data.data(), n = first(x.name), txt = String(x.text || '').slice(0, 120);
  const title = x.kind === 'ask' ? `🙋 ${n} needs help` : x.kind === 'announce' ? '📣 Announcement' : x.kind === 'photo' ? `📸 ${n} shared a memory` : x.kind === 'tip' ? `💡 Tip from ${n}` : x.kind === 'idea' ? `💡 New idea from ${n}` : `💬 ${n} posted`;
  await send(await everyoneBut(x.name), title, txt || 'Tap to see it in the Club', '#club', 'post-' + e.params.id, x.kind === 'ask' ? 'ask' : x.kind === 'announce' ? 'announce' : 'post');
});

// Comments: tell the post's author
exports.onComment = onDocumentCreated(P + 'comments/{id}', async e => {
  const c = e.data.data();
  if (!String(c.target || '').startsWith('post:')) return;
  const p = await db.collection(P + 'posts').doc(c.target.slice(5)).get();
  if (!p.exists || key(p.data().name) === key(c.name)) return;
  const t = String(c.text || '');
  await send(await only(p.data().name), `💬 ${first(c.name)} commented`, t.startsWith('[gif]') ? 'sent a GIF' : t.startsWith('[stk]') ? 'sent a sticker' : (t.slice(0, 120) || (c.img ? '📷 sent a photo' : '')), '#club', '', 'comment');
});

// Avokudos: tell the person who received them
exports.onAvo = onDocumentCreated(P + 'avo/{id}', async e => {
  const g = e.data.data();
  await send(await only(g.to), `🥑 ${first(g.from)} appreciated you${g.amt ? ' · ' + g.amt + ' Avokudos' : ''}`, String(g.msg || '').slice(0, 120), '#club', '', 'avo');
});

// New availability poll: everyone
exports.onPoll = onDocumentCreated(P + 'polls/{id}', async e => {
  const p = e.data.data();
  await send(await tokens(), '🗳️ New poll: ' + (p.title || 'Are you in?'), 'Tap to vote Yes or No', '#poll-' + e.params.id, '', 'poll');
});

// Payments: organizers hear about "I've paid"; the player hears when it's confirmed
exports.onPayment = onDocumentCreated(P + 'payments/{id}', async e => {
  const x = e.data.data();
  if (x.status !== 'claimed') return;
  await send(await organizers(), `💸 ${first(x.payer || x.name)} says they paid ${inr(x.amount)}`, 'Check your UPI app and confirm', '#confirm', '', 'pay');
});
exports.onPaymentConfirmed = onDocumentUpdated(P + 'payments/{id}', async e => {
  const a = e.data.before.data(), b = e.data.after.data();
  if (a.status === 'claimed' && b.status === 'confirmed')
    await send(await tokens(t => key(t.name) === key(b.name) || key(t.name) === key(b.payer)), '✅ Payment confirmed', `${inr(b.amount)} received. Thank you! 💚`, '#payouts', '', 'paid');
});

// Ideas & problems: organizers
exports.onRequest = onDocumentCreated(P + 'requests/{id}', async e => {
  const r = e.data.data();
  await send(await organizers(), `${r.kind === 'bug' ? '🐞 Problem' : r.kind === 'q' ? '❓ Question' : '💡 Idea'} from ${first(r.name)}`, String(r.text || '').slice(0, 120), '#ideas', '', 'idea');
});

// Challenges: the people being challenged
exports.onChallenge = onDocumentCreated(P + 'challenges/{id}', async e => {
  const c = e.data.data(), who = (c.b || []).map(key);
  await send(await tokens(t => who.includes(key(t.name))), `⚔️ ${first(c.from)} challenged you`, String(c.msg || 'Accept the challenge?').slice(0, 120), '#cup', '', 'chal');
});

// Ideas & problems: the person who raised it hears every status change
const STG = { review: '🔎 In review', clarify: '❓ Pending clarification', dev: '🛠️ In development', test: '🧪 Internal testing', uat: '🙋 User testing', prod: '🚀 Go-live', awaiting: '⏳ Awaiting prioritisation', backlog: '📋 Added to backlog', hold: '⏸️ On hold', done: '✅ Done', dropped: '🚫 Dropped', abandoned: '🕸️ Abandoned' };
exports.onRequestUpdate = onDocumentUpdated(P + 'requests/{id}', async e => {
  const a = e.data.before.data(), b = e.data.after.data();
  const lbl = b.status === 'custom' ? '🏷️ ' + String(b.stageLabel || 'Update') : STG[b.status];
  if (!b.uid || !lbl || (a.status === b.status && (a.stageLabel || '') === (b.stageLabel || ''))) return;
  const code = b.code || ({ idea: 'IDEA', bug: 'PRB', q: 'ASK' }[b.kind] || 'TKT') + '-' + e.params.id.slice(-4).toUpperCase();
  const last = (b.replies || []).slice(-1)[0] || {};
  await send(await tokens(t => t.id === b.uid), `🎫 ${code} → ${lbl}`, String(last.text || 'Tap to see the update').slice(0, 120), '#mytickets', 'tk-' + e.params.id, 'ticket');
});

// Private replies to a status: only the person who posted it hears about it
exports.onReply = onDocumentCreated(P + 'replies/{id}', async e => {
  const r = e.data.data();
  await send(await tokens(t => t.id === r.toUid), `💬 ${first(r.from)} replied to your status`, String(r.text || '').slice(0, 120), '#home', 'reply-' + e.params.id, 'comment');
});

// Game proposals: admins hear about new ones; the player hears the answer
const sched = x => { try { const d = new Date(x.date + 'T00:00'); return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' }) + (x.note ? ' · ' + x.note : ''); } catch (e) { return ''; } };
exports.onProposal = onDocumentCreated(P + 'actions/{id}', async e => {
  const a = e.data.data();
  if (a.kind !== 'poll' || a.status !== 'pending') return;
  let x = {}; try { x = JSON.parse(a.value); } catch (err) {}
  await send(await organizers(), `🗓 ${first(a.name)} proposes a game`, sched(x) + (x.msg ? ' · “' + String(x.msg).slice(0, 80) + '”' : ''), '#proposals', 'prop-' + e.params.id, 'proposal');
});
exports.onProposalAnswer = onDocumentUpdated(P + 'actions/{id}', async e => {
  const a = e.data.before.data(), b = e.data.after.data();
  if (b.kind !== 'poll' || a.status !== 'pending' || b.status === 'pending') return;
  const r = b.reply || {}, who = await tokens(t => t.id === b.uid || key(t.name) === key(b.name));
  const title = b.status === 'declined' ? '✖ Your game proposal was declined' : r.how === 'modified' ? '✏️ Your game was changed & published' : '✅ Your game proposal is live';
  await send(who, title, (r.date ? sched(r) : '') + (r.msg ? ' · “' + String(r.msg).slice(0, 80) + '”' : ''), r.poll ? '#poll-' + r.poll : '', 'prop-' + e.params.id, 'proposal');
});

// Every morning at 8:00 IST: birthdays, anniversaries and today's game
// Guests: tell admins when a player adds a guest, and tell the player when their guest is approved
const gkeys = v => { const o = {}; Object.entries((v && v.guests) || {}).forEach(([d, L]) => (L || []).forEach(g => { if (g && g.n) o[d + '|' + key(g.n)] = g.n; })); return o; };
const dshort = d => new Date(d + 'T00:00').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
exports.onGuestVote = onDocumentWritten(P + 'polls/{pid}/votes/{vid}', async e => {
  const b = e.data.after.exists ? e.data.after.data() : null; if (!b) return;
  const a = e.data.before.exists ? gkeys(e.data.before.data()) : {}, nw = Object.entries(gkeys(b)).filter(([k]) => !a[k]);
  if (!nw.length) return;
  const names = nw.map(([k, n]) => n + ' (' + dshort(k.split('|')[0]) + ')').join(', ');
  await send(await organizers(), `👥 ${first(b.name)} wants to bring ${nw.length === 1 ? 'a guest' : nw.length + ' guests'}`, names + ' · tap to approve', '#poll-' + e.params.pid, 'guest-' + e.params.pid, 'guest');
});
exports.onGuestOk = onDocumentUpdated(P + 'polls/{pid}', async e => {
  const a = e.data.before.data().guestOk || {}, b = e.data.after.data().guestOk || {};
  for (const [d, L] of Object.entries(b)) {
    for (const k of (L || [])) {
      if ((a[d] || []).includes(k)) continue;
      const [host, g] = k.split(':');
      await send(await tokens(t => key(t.name).replace(/\s+/g, '') === host.replace(/\s+/g, '') || key(t.name) === host), `✅ Your guest is confirmed`, `${g.replace(/\b\w/g, c => c.toUpperCase())} can play on ${dshort(d)}. See you on court! 🏸`, '#poll-' + e.params.pid, 'gok-' + d + k, 'guest');
    }
  }
});

exports.morning = onSchedule({ schedule: '0 8 * * *', timeZone: 'Asia/Kolkata' }, async () => {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
  const ymd = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0'), md = ymd.slice(5);
  const all = await tokens();
  const profs = await db.collection(P + 'profiles').get();
  for (const d of profs.docs) {
    const p = d.data();
    if (p.bday === md) await send(all, `🎂 It’s ${first(p.name)}’s birthday today!`, 'Send a wish in the app 💌', '#club', 'bday-' + d.id, 'occasion');
    if (p.anniv === md) await send(all, `💍 Happy anniversary, ${first(p.name)}!`, 'Send your wishes in the app 💌', '#club', 'anniv-' + d.id, 'occasion');
  }
  const occ = await db.collection(P + 'occasions').where('date', '==', ymd).get();
  for (const d of occ.docs) { const o = d.data(); await send(all, `${o.emoji || '🎉'} ${first(o.who)}: ${o.title || 'a special day'}!`, 'Send your wishes in the app 💌', '#club', '', 'occasion'); }
  const polls = await db.collection(P + 'polls').orderBy('createdAt', 'desc').limit(10).get();
  for (const d of polls.docs) {
    const p = d.data(), dt = (p.dates || []).find(x => x.date === ymd);
    if (dt && !p.archived) await send(all, '🏸 Game day today' + (dt.note ? ' · ' + dt.note : ''), 'See who’s in and get directions', '#home', '', 'game');
  }
});

// ===================== Autopilot (v4.14) =====================
// Runs every 15 minutes. Admins switch each job on/off in the app: Manage › Autopilot (config main.auto).
// Everything is idempotent: each job writes a key into shuttleSplit_config/autopilot so it never repeats.
const AUTO_DEF = { poll: { on: true, dow: 1, at: '20:00' }, remind: true, last: true, pass: true, game: true, thanks: true, dues: true };
const IST = () => new Date(Date.now() + 5.5 * 3600e3); // read with getUTC*
const ymdOf = d => d.toISOString().slice(0, 10);
const istMs = (date, h) => new Date(date + 'T00:00:00Z').getTime() - 5.5 * 3600e3 + h * 3600e3; // IST wall clock -> epoch ms
const mins = v => { const [h, m] = String(v || '0:0').split(':').map(Number); return (h || 0) * 60 + (m || 0); };
function slot(note) { // "5-7 PM", "9-11 AM", "6:30-8 PM", "11 AM-1 PM" -> {s,e} hours
  const m = String(note || '').match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*(?:-|–|to)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i);
  if (!m) return { s: 17, e: 19 };
  const ap2 = (m[6] || m[3] || 'pm').toLowerCase(), ap1 = (m[3] || '').toLowerCase();
  let e = (+m[4] % 12) + (+m[5] || 0) / 60 + (ap2 === 'pm' ? 12 : 0), s = (+m[1] % 12) + (+m[2] || 0) / 60;
  if (ap1) s += ap1 === 'pm' ? 12 : 0; else { s += ap2 === 'pm' ? 12 : 0; if (s > e) s -= 12; }
  if (e <= s) e = s + 2;
  return { s, e };
}
const dlabel = d => new Date(d + 'T00:00:00Z').toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', timeZone: 'UTC' });
const hm = h => { const H = Math.floor(h), M = Math.round((h - H) * 60), ap = H >= 12 ? 'PM' : 'AM', h12 = ((H + 11) % 12) + 1; return h12 + (M ? ':' + String(M).padStart(2, '0') : '') + ' ' + ap; };
const passLinkF = (pid, date, name) => 'pass-' + pid + '-' + date + '-' + encodeURIComponent(key(name));
const byNames = async names => { const ks = new Set(names.map(key)); return tokens(t => ks.has(key(t.name))); };
async function votesOf(pid) { const q = await db.collection(P + 'polls').doc(pid).collection('votes').get(); return q.docs.map(d => d.data()); }
const isClosedP = (p, now) => p.closed === true || (p.closesAt && now >= p.closesAt);

exports.autopilot = onSchedule({ schedule: 'every 15 minutes', timeZone: 'Asia/Kolkata' }, async () => {
  const cfgDoc = await db.collection(P + 'config').doc('main').get(); if (!cfgDoc.exists) return;
  const C = cfgDoc.data(), A = Object.assign({}, AUTO_DEF, C.auto || {}); if (A.on === false) return;
  const M = Object.assign({ days: [3, 5], at: '20:00', lastCall: true, gameLead: 2, duesOn: false, duesDays: [1], duesAt: '19:00' }, C.msg || {});
  const stRef = db.collection(P + 'config').doc('autopilot'), st = (await stRef.get()).data() || {}, sent = st.sent || {}, did = {};
  const once = k => { if (sent[k] || did[k]) return false; did[k] = Date.now(); return true; };
  const now = Date.now(), I = IST(), today = ymdOf(I), dow = I.getUTCDay(), nowMin = I.getUTCHours() * 60 + I.getUTCMinutes();
  const roster = (C.roster || []).filter(n => !(C.inactive || []).includes(key(n)));
  const polls = (await db.collection(P + 'polls').orderBy('createdAt', 'desc').limit(12).get()).docs.map(d => ({ id: d.id, ...d.data() })).filter(p => !p.archived);

  // A · create next week's poll from last week's
  try {
    const AP = Object.assign({}, AUTO_DEF.poll, A.poll || {});
    if (AP.on && dow === +AP.dow && nowMin >= mins(AP.at) && once('poll:' + today)) {
      const hasFuture = polls.some(p => !isClosedP(p, now) && (p.dates || []).some(d => d.date > today));
      const last = polls.find(p => (p.dates || []).length);
      if (!hasFuture && last) {
        const dates = last.dates.map(d => { let x = new Date(d.date + 'T00:00:00Z'); while (ymdOf(x) <= today) x = new Date(x.getTime() + 7 * 864e5); return { date: ymdOf(x), note: d.note || '' }; }).sort((a, b) => a.date.localeCompare(b.date));
        const R = Object.assign({ d: 1, at: '22:00' }, C.closeRule || {}), f = dates[0].date, fx = new Date(new Date(f + 'T00:00:00Z').getTime() - (+R.d || 0) * 864e5);
        let closesAt = istMs(ymdOf(fx), mins(R.at) / 60); if (closesAt < now + 3600e3) closesAt = null;
        const ref = await db.collection(P + 'polls').add({ title: last.title || 'Who’s up for Badminton this weekend?', dates, perCourt: last.perCourt || 4, closed: false, closesAt, createdAt: now, auto: true });
        did['pollid:' + ref.id] = now;
      }
    }
  } catch (e) { console.error('A', e); }

  for (const p of polls) {
    let V = null; const vs = async () => V || (V = await votesOf(p.id));
    const open = !isClosedP(p, now);
    // B · voting reminders to people who haven't voted
    try {
      if (A.remind && open && (M.days || []).includes(dow) && nowMin >= mins(M.at) && (p.dates || []).some(d => d.date >= today) && once('remind:' + p.id + ':' + today)) {
        const voted = new Set((await vs()).map(v => key(v.name))), pend = roster.filter(n => !voted.has(key(n)));
        if (pend.length) await send(await byNames(pend), '🗳️ Are you in this week?', (p.title || 'Vote for the next game') + ' · tap to vote, it takes 5 seconds', '#poll-' + p.id, 'remind-' + p.id, 'poll');
      }
    } catch (e) { console.error('B', e); }
    // C · last call, 1 hour before voting closes
    try {
      if (A.last && M.lastCall !== false && open && p.closesAt && p.closesAt - now <= 3600e3 && p.closesAt > now && once('last:' + p.id)) {
        const voted = new Set((await vs()).map(v => key(v.name))), pend = roster.filter(n => !voted.has(key(n)));
        if (pend.length) await send(await byNames(pend), '⏰ Last call: voting closes in an hour', (p.title || 'Vote now') + ' · tap to vote', '#poll-' + p.id, 'last-' + p.id, 'poll');
      }
    } catch (e) { console.error('C', e); }
    for (const dt of (p.dates || [])) {
      if (dt.date !== today) continue;
      const S2 = slot(dt.note), start = istMs(dt.date, S2.s), end = istMs(dt.date, S2.e);
      // G · game reminder to Yes voters, with their pass
      try {
        const lead = +M.gameLead || 2;
        if (A.game && lead > 0 && now >= start - lead * 3600e3 && now < start && once('game:' + p.id + ':' + dt.date)) {
          for (const v of (await vs()).filter(v => (v.answers || {})[dt.date] === 'yes'))
            await send(await only(v.name), `🏸 Game at ${hm(S2.s)} today`, `See you on court, ${first(v.name)}! Your entry pass is ready 🎟️`, '#' + passLinkF(p.id, dt.date, v.name), 'game-' + dt.date, 'game');
        }
      } catch (e) { console.error('G', e); }
      // K · thank-you after the game
      try {
        if (A.thanks && now >= end && now < end + 4 * 3600e3 && once('thanks:' + p.id + ':' + dt.date)) {
          const yes = (await vs()).filter(v => (v.answers || {})[dt.date] === 'yes').map(v => v.name);
          if (yes.length) await send(await byNames(yes), '💚 Thanks for playing today!', 'What a game! Rest up, stretch, and see you on court next time 🏸', '#home', 'thanks-' + dt.date, 'game');
        }
      } catch (e) { console.error('K', e); }
    }
  }

  // J · payment reminders (amounts published by the organizer's app in config main.duesSnap)
  try {
    if (A.dues && M.duesOn && (M.duesDays || []).includes(dow) && nowMin >= mins(M.duesAt) && once('dues:' + today)) {
      for (const x of ((C.duesSnap || {}).list || []).filter(x => x.amt > 0))
        await send(await only(x.n), '💸 Gentle reminder: ' + inr(x.amt) + ' due', 'Whenever it suits you 💚 Open Payouts to pay, then tap “I’ve paid”.', '#payouts', 'dues', 'pay');
    }
  } catch (e) { console.error('J', e); }

  if (Object.keys(did).length) {
    const keep = {}; Object.entries(sent).forEach(([k, t]) => { if (now - t < 40 * 864e5) keep[k] = t; });
    await stRef.set({ sent: Object.assign(keep, did), at: now });
  }
});

// F · entry pass alerts the moment someone votes Yes, and a kind cancellation if they switch to No
exports.onPassVote = onDocumentWritten(P + 'polls/{pid}/votes/{vid}', async e => {
  const b = e.data.after.exists ? e.data.after.data() : null; if (!b || !b.name) return;
  const C = ((await db.collection(P + 'config').doc('main').get()).data()) || {}, A = Object.assign({}, AUTO_DEF, C.auto || {});
  if (A.on === false || !A.pass || C.passOn === false) return;
  const a = e.data.before.exists ? (e.data.before.data().answers || {}) : {}, n = b.answers || {}, today = ymdOf(IST());
  const p = (await db.collection(P + 'polls').doc(e.params.pid).get()).data() || {}, note = d => ((p.dates || []).find(x => x.date === d) || {}).note || '';
  const venue = ((C.board || {}).venue) || 'the courts';
  for (const d of Object.keys(n)) {
    if (d < today) continue;
    if (n[d] === 'yes' && a[d] !== 'yes')
      await send(await only(b.name), `🎟️ You’re in! Pass for ${dlabel(d)}`, `Great, see you on court at ${venue}${note(d) ? ' · ' + note(d) : ''} 🏸 Tap to open your entry pass.`, '#' + passLinkF(e.params.pid, d, b.name), 'pass-' + d, 'pass');
    else if (a[d] === 'yes' && n[d] !== 'yes')
      await send(await only(b.name), `💔 We’ll miss you on ${dlabel(d)}`, 'Your pass is cancelled. You’ll miss the fun, but we look forward to having you at the next game 💚', '#' + passLinkF(e.params.pid, d, b.name), 'pass-' + d, 'pass');
  }
});
